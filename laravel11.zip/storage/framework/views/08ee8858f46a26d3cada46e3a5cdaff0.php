<footer class="text-tertiary">
    <div class="flex justify-center items-center py-12 px-32">
        <a href="#" class="text-dark text-opacity-75 mx-2 fs-6" style="text-decoration: none">Home</a>
        <span class="text-dark text-opacity-75 mx-1" style="font-size: 0.2em;"><i class="fa-solid fa-circle"></i></span>
        <a href="#" class="text-dark text-opacity-75 mx-2 fs-6" style="text-decoration: none">About</a>
        <span class="text-dark text-opacity-75 mx-1" style="font-size: 0.2em;"><i class="fa-solid fa-circle"></i></span>
        <a href="#" class="text-dark text-opacity-75 mx-2 fs-6" style="text-decoration: none">Blog</a>
        <span class="text-dark text-opacity-75 mx-1" style="font-size: 0.2em;"><i class="fa-solid fa-circle"></i></span>
        <a href="#" class="text-dark text-opacity-75 mx-2 fs-6" style="text-decoration: none">Contact</a>
    </div>
</footer><?php /**PATH C:\Users\rvd\Herd\laravel11\resources\views/components/footer.blade.php ENDPATH**/ ?>