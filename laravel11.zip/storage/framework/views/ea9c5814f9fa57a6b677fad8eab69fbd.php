<script>
    const burgerIcon = document.getElementById('burger-icon');
    const mobileMenu = document.getElementById('mobile-menu');

    burgerIcon.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
    });
</script>
<?php /**PATH C:\Users\rvd\Herd\laravel11\resources\views/components/script.blade.php ENDPATH**/ ?>